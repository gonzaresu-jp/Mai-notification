<!doctype html>
<html lang="ja">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>このサービスについて</title>
    <link rel="icon" href="/icon.webp">
    <link rel="stylesheet" href="/style.v2.0.css" />
    <style type="text/css">
        .service-intro {
  font-size: 1rem;
  background: rgba(250, 250, 250, 0.85);
  color: #000;
  border-radius: 12px;
  padding: 32px;
  margin-bottom: 20px;
  line-height: 1.7;
}
.intro-text {font-size: 24px; font-weight: bold;}

.platform-list {
  margin: 16px 0;
  padding-left: 1.2em;
}

.platform-list li {
  margin-bottom: 8px;
}

.note {
  display: block;
  font-size: 1em;
  color: #444;
  margin-top: 4px;
}

.latency {
  margin-top: 24px;
}

.latency h3 {
  font-size: 1.1em;
  margin-bottom: 8px;
}

.latency ul {
  padding-left: 1.2em;
}

.future {
  margin-top: 16px;
  font-style: italic;
}

.link {
  margin-top: 20px;
}

    </style>
</head>
<body id="app-body">
    <div id="header-slot">
        <?php include __DIR__ . '/header.html'; ?>
    </div>

    <main>
<section class="service-intro">
  <p class="intro-text">
    このサービスは、まいちゃんに関する通知を確実に受け取ることを目的として開発しました。
    対応している通知プラットフォームは以下の通りです。
  </p>
  <hr>
  <ul class="platform-list">
    <li>ツイキャス</li>
    <li>YouTube（配信・動画・<s>コミュニティ投稿</s>）</li>
    <li>Twitter
      <span class="note">※ファンクラブ限定アカウントは通知のみ行い、内容は表示しません。</span>
    </li>
    <li>Pixiv Fanbox（ファンクラブ）</li>
  </ul>

  <p class="settings-text">
    各プラットフォームの通知は個別に有効・無効を設定できます。
  </p>

  <div class="latency">
    <h3>通知遅延について</h3>
    <ul>
      <li>ツイキャス / YouTube（配信・動画）：ほぼ無遅延</li>
      <li>Twitter：約1分</li>
      <li>YouTubeコミュニティ投稿（停止中）/ Pixiv Fanbox：約3分</li>
    </ul>
  </div>

  <p class="future">
    今後、bilibili や Twitch での配信があれば対応予定です。
  </p>

  <p class="link">
    使用方法は
    <a href="https://github.com/gonzaresu-jp/Mai-notification" target="_blank" rel="noopener noreferrer">
      GitHub
    </a>
    を参照してください。
  </p>
</section>
<a href="/" 
   style="text-decoration:none; color:inherit; display:block;">
    <div style="
        background-color:#FFF;
        min-height:60px;
        display:flex;
        align-items:center;
        justify-content:center;
        padding:10px 20px; /* ←クリック範囲を広げる */
    ">
        <h3 style="margin:0;">通知ダッシュボードに戻る</h3>
    </div>
</a>




    </main>

    <div id="footer-slot">
        <?php include __DIR__ . '/footer.html'; ?>
    </div>

<!-- iOS Helper を main.js より先に読み込む -->
    <script src="/ios-helper.js" defer></script>
    <script type="module" src="/js/main.js" defer></script>
    <script>
const btn = document.getElementById('btn-log-settings');
const menu = document.getElementById('log-settings-container');

btn.addEventListener('click', () => {
  const open = menu.classList.toggle('is-open');
  btn.setAttribute('aria-expanded', open);
  menu.setAttribute('aria-hidden', !open);
});

// メニュー外クリックで閉じる
document.addEventListener('click', (e) => {
  if (!btn.contains(e.target) && !menu.contains(e.target)) {
    menu.classList.remove('is-open');
    btn.setAttribute('aria-expanded', false);
    menu.setAttribute('aria-hidden', true);
  }
});

</script>

<script>
function initOshiDays() {
  const STORAGE_KEY = "maistart_date";
  const DEFAULT_DATE = "2020-01-07";
  const MS_PER_DAY = 24 * 60 * 60 * 1000;

  const dateInput = document.getElementById("start");              // header内
  const meetValueEl = document.getElementById("days-to-meet");     // main内
  const meetStatItem = meetValueEl?.closest(".stat-item");

  if (!meetValueEl || !meetStatItem) return; // 表示側がないなら何もしない
  if (!dateInput) return;                    // headerが未挿入なら何もしない（待つ側で保証する）

  function parseYMD(ymd) {
    if (!ymd) return null;
    const parts = ymd.split("-").map(Number);
    if (parts.length !== 3 || parts.some(Number.isNaN)) return null;
    return new Date(parts[0], parts[1] - 1, parts[2], 0, 0, 0, 0);
  }
  function stripTime(d) {
    return new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, 0, 0, 0);
  }
  function daysSinceLocal(date) {
    const now = stripTime(new Date()).getTime();
    const then = stripTime(date).getTime();
    return Math.max(0, Math.floor((now - then) / MS_PER_DAY));
  }

  function loadAndApply() {
    const stored = localStorage.getItem(STORAGE_KEY);
    let effective = stored || dateInput.value || null;

    // DEFAULT_DATE を「未設定扱い」
    if (!effective || effective === DEFAULT_DATE) {
      meetStatItem.style.display = "none";
      meetValueEl.textContent = "0 日";
      if (!stored) dateInput.value = "";
      return;
    }

    const parsed = parseYMD(effective);
    if (!parsed) {
      meetStatItem.style.display = "none";
      return;
    }

    const since = daysSinceLocal(parsed);
    meetValueEl.textContent = `${since} 日`;
    meetStatItem.style.display = "";
    if (dateInput.value !== effective) dateInput.value = effective;
  }

  function saveDate(value) {
    if (!value || value === DEFAULT_DATE) localStorage.removeItem(STORAGE_KEY);
    else localStorage.setItem(STORAGE_KEY, value);
    loadAndApply();
  }

  // 多重登録防止
  if (dateInput.dataset.boundOshiDays === "1") {
    loadAndApply();
    return;
  }
  dateInput.dataset.boundOshiDays = "1";

  loadAndApply();
  dateInput.addEventListener("change", (e) => saveDate(e.target.value));

  // 「保存」ボタン（ユーザー名保存と共用）でも保存したいなら
  const saveBtn = document.getElementById("subscriber-name-submit");
  if (saveBtn && !saveBtn.dataset.boundOshiDays) {
    saveBtn.dataset.boundOshiDays = "1";
    saveBtn.addEventListener("click", () => saveDate(dateInput.value));
  }

  // 日付跨ぎ対策
  setInterval(loadAndApply, 60 * 1000);
}


(async () => {
  const load = async (id, url) => {
    const el = document.getElementById(id);
    if (!el) return;
    const res = await fetch(url, { cache: 'no-cache' });
    el.innerHTML = await res.text();
  };

  await load('header-slot', '/header.html');
  initOshiDays();               // ← ここが重要：header 注入後に初期化
  await load('footer-slot', '/footer.html');
})();
</script>
<script>
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('./service-worker.js')
            .then(reg => console.log('Service Worker 登録成功', reg))
            .catch(err => console.error('Service Worker 登録失敗', err));
    }

// 1. フェードイン用関数（定義するだけ。ロード時は呼ばない）
    function applyHamburgerSequentialFadeIn() {
        const menuItems = document.querySelectorAll('#nav-menu > .nav-list > li');
        const delayIncrement = 100; 

        menuItems.forEach((item, index) => {
            const delay = index * delayIncrement;
            setTimeout(() => {
                item.classList.add('is-faded-in');
            }, delay);
        });
    }

    document.addEventListener('DOMContentLoaded', () => {
    const body = document.getElementById('app-body');

    // 1) 初期はトランジション無効（bodyに class を付けておく）
    //    ここでは最小遅延で「初回描画を挟んで」トランジションを有効にする。
    requestAnimationFrame(() => {
        // 1フレーム待ってからさらに次フレームで class を除去 → トランジションが発火するのは以降の操作だけ
        requestAnimationFrame(() => {
            body.classList.remove('menu-transitions-disabled');
        });
    });

    // --- 以下は既存の初期化処理（メニュー初期化等） ---
    const toggle = document.getElementById('hamburger-toggle');
    const overlay = document.getElementById('menu-overlay');
    const notifyToggle = document.getElementById('toggle-notify');

    // メニュー項目集合
    const menuItems = document.querySelectorAll('#nav-menu > .nav-list > li');
    // 初期状態として is-faded-in を外しておく（念のため）
    menuItems.forEach(item => item.classList.remove('is-faded-in'));

    function applyHamburgerSequentialFadeIn() {
        const delayIncrement = 100;
        menuItems.forEach((item, index) => {
            const delay = index * delayIncrement;
            setTimeout(() => {
                item.classList.add('is-faded-in');
            }, delay);
        });
    }

    function toggleMenu(isOpen) {
        if (isOpen) {
            // 開くときはまずクラスを外して確実に 0 → 1 の遷移が発生するように
            menuItems.forEach(item => item.classList.remove('is-faded-in'));

            body.classList.add('menu-open');
            toggle.setAttribute('aria-expanded', 'true');
            overlay.style.display = 'block';

            // スライド等の外枠アニメーションがあるなら遅延（既定値の 300ms 等）
            setTimeout(() => applyHamburgerSequentialFadeIn(), 300);
        } else {
            body.classList.remove('menu-open');
            toggle.setAttribute('aria-expanded', 'false');
            overlay.style.display = 'none';
            menuItems.forEach(item => item.classList.remove('is-faded-in'));
        }
    }

    // --- 右端スワイプでメニュー開閉 ---
// 挿入場所: document.addEventListener('DOMContentLoaded', ...) 内、toggleMenu 定義の直後
(function installRightEdgeSwipeMenu() {
    const EDGE_START = 270;
    const OPEN_THRESHOLD = 60;
    const CLOSE_THRESHOLD = 60;
    const MAX_VERTICAL_DELTA = 30;
    let pointerActive = false;
    let startX = 0, startY = 0;
    let trackingForOpen = false;
    let trackingForClose = false;

    function isMenuOpen() {
        return document.body.classList.contains('menu-open');
    }

    function onPointerDown(e) {
        const x = e.clientX || (e.touches && e.touches[0].clientX);
        const y = e.clientY || (e.touches && e.touches[0].clientY);

        startX = x; startY = y;
        pointerActive = true;
        trackingForOpen = false;
        trackingForClose = false;

        if (!isMenuOpen() && startX >= (window.innerWidth - EDGE_START)) {
            trackingForOpen = true;
        }

        if (isMenuOpen()) {
            const menu = document.getElementById('nav-menu');
            const overlay = document.getElementById('menu-overlay');
            const target = e.target || (e.touches && e.touches[0].target);
            
            if (overlay && overlay.style.display !== 'none' && overlay.contains(target)) {
                trackingForClose = true;
            } else if (menu) {
                const r = menu.getBoundingClientRect();
                if (startX >= r.left && startX <= r.right && startY >= r.top && startY <= r.bottom) {
                    trackingForClose = true;
                }
            }
        }
    }

    function onPointerMove(e) {
        if (!pointerActive) return;
        
        const x = e.clientX || (e.touches && e.touches[0].clientX);
        const y = e.clientY || (e.touches && e.touches[0].clientY);
        const dx = x - startX;
        const dy = y - startY;

        if (Math.abs(dy) > MAX_VERTICAL_DELTA) {
            trackingForOpen = false;
            trackingForClose = false;
            return;
        }

        if (trackingForOpen && dx < -OPEN_THRESHOLD) {
            toggleMenu(true);
            trackingForOpen = false;
            pointerActive = false;
            if (e.cancelable) e.preventDefault();
            return;
        }

        if (trackingForClose && dx > CLOSE_THRESHOLD) {
            toggleMenu(false);
            trackingForClose = false;
            pointerActive = false;
            if (e.cancelable) e.preventDefault();
            return;
        }
    }

    function onPointerUp() {
        pointerActive = false;
        trackingForOpen = false;
        trackingForClose = false;
    }

    // タッチデバイス優先で登録
    if ('ontouchstart' in window) {
        // タッチデバイスの場合
        document.addEventListener('touchstart', onPointerDown, { passive: true });
        document.addEventListener('touchmove', onPointerMove, { passive: false }); // passive: false が重要
        document.addEventListener('touchend', onPointerUp, { passive: true });
        document.addEventListener('touchcancel', onPointerUp, { passive: true });
    } else if (window.PointerEvent) {
        // Pointer Events 対応デバイス
        document.addEventListener('pointerdown', onPointerDown, { passive: true });
        document.addEventListener('pointermove', onPointerMove, { passive: false });
        document.addEventListener('pointerup', onPointerUp, { passive: true });
        document.addEventListener('pointercancel', onPointerUp, { passive: true });
    }
})();

    toggle.addEventListener('click', () => {
        const isExpanded = toggle.getAttribute('aria-expanded') === 'true';
        toggleMenu(!isExpanded);
    });
    overlay.addEventListener('click', () => toggleMenu(false));

    if (notifyToggle) {
        function updateToggleImage() {
            if (notifyToggle.checked) body.classList.add('notifications-enabled');
            else body.classList.remove('notifications-enabled');
        }
        notifyToggle.addEventListener('change', updateToggleImage);
        setTimeout(updateToggleImage, 100);
    }
});

</script>
<script type="module">
  window.__layoutReady = (async () => {
    const load = async (id, url) => {
      const el = document.getElementById(id);
      if (!el) return;
      const res = await fetch(url, { cache: 'no-cache' });
      el.innerHTML = await res.text();
    };

    await load('header-slot', '/header.html');
    window.initHeader?.();
    await load('footer-slot', '/footer.html');
  })();
</script>
</body>
</html>